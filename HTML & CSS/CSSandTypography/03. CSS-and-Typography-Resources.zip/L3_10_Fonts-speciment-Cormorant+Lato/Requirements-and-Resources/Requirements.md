﻿# 10 - Fonts Speciment - Cormorant + Lato
------
Problems for in-class lab for the [�HTML & CSS�](https://softuni.bg/trainings/2375/html-and-css-may-2019) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1234/CSS-Typography).

## Tasks
 * Create an **index.html** file with **Fonts Speciment Cormorant + Lato** title 
* Use **Lato, sans-serif**  font-family for the document
	* Make the **font-size** 16px
	* Change the **line-height** to 1.5
* Use **Cormorant, serif** font-family for the headings	
	* Change the **line-height** to 1.2
	* Change the font weight to **bold**

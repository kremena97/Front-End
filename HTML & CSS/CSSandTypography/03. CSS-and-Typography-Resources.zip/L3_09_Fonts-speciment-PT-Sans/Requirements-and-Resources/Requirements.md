# 09 - Fonts Speciment PT Sans
------
Problems for in-class lab for the [�HTML & CSS�](https://softuni.bg/trainings/2375/html-and-css-may-2019) course @ **SoftUni**.

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1234/CSS-Typography).

## Tasks
 * Create an **index.html** file with **Fonts Speciment PT Sans** title 
	* Create an HTML page which holds an **article**
	* Use **h1** and **h2** tags for headings
	* Use **ul** and **ol** tags for lists 
	* Use **PT Sans** font-family for the document
	* Make the **font-size** 16px
	* Change the **line-height** to 1.5
